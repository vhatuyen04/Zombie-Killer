Hello,
Thanks for downloading one of my pixel arts!

This tile set contains 7 images for explosion animation

This is one of my first pixel art projects and I decided to share it with everyone 
and also see my progress and growth over time as I'll upload more and more

Do not claim it as your own or do not sell it!

Enjoy! :)

My Behance: https://www.behance.net/mareksefcik
My profile: https://agresko.itch.io/
Link to this project: https://agresko.itch.io/explosion-animation---7x